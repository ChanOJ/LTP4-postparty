@echo off
if %1!==! set FASTCODE=FastCode
if not %1!==! set FASTCODE=FstCode%1
debug < %FASTCODE%.dbg > %FASTCODE%.log
if %COMPUTERNAME%!==DOLMEN! start %FASTCODE%.log