; LTP 4 Fast Code
; By ChoJin
; Real algo was not finished ...

.model small
.486

GRID_SIZE=16

.code

org 100h
start:

	; UnCrunching
	mov si,offset GridCompressed
	mov di,offset Grid
	mov cl,((GRID_SIZE/2)*GRID_SIZE)
	UnCrunching_Loop:
		lodsb
		push ax
		shr al,4
		add al,'a'-1
		stosb
		pop ax
		and al,0Fh
		add al,'a'-1
		stosb
	dec cl
	jnz UnCrunching_Loop
	
	; Parse Command line
	mov si,82h
	mov di,offset Grid+GRID_SIZE*4+6
	movsd
	
	mov si,offset Grid
	mov cl,GRID_SIZE
	mov ebp,00240A0Dh
	Line_Loop:
	xchg ebp,dword ptr [si+16]
	mov ah,9
	mov dx,si
	int 21h
	xchg ebp,dword ptr [si+16]
	add si,GRID_SIZE	
	dec cl
	jnz Line_Loop
	
exit:
	mov ah,4ch
	int 21h


; ******************************************************************************* ;
; **************************          DATA        ******************************* ;
; ******************************************************************************* ;

; grid in  4 bit format :
; 0000 = 0h = hole
; 0001 = 1h = a
; 0010 = 2h = b
; 0011 = 3h = c
; 0100 = 4h = d
_??=00h
_?a=01h
_?b=02h
_?c=03h
_?d=04h
_a?=10h
_b?=20h
_c?=30h
_d?=40h
_aa=11h
_ab=12h
_ac=13h
_ad=14h
_ba=21h
_bb=22h
_bc=23h
_bd=24h
_ca=31h
_cb=32h
_cc=33h
_cd=34h
_da=41h
_db=42h
_dc=43h
_dd=44h

; Grid  Each line of this Variable are Column of the grid , from bottom to up

GridCompressed	DB _ad,_bd,_cd,_bd,_dd,_cb,_db,_ab
		DB _bc,_cb,_dd,_bc,_ca,_ad,_cd,_aa
		DB _da,_bd,_ac,_db,_bd,_ac,_ac,_cd
		DB _cd,_ab,_ab,_ca,_cb,_dc,_ad,_ca
		DB _ba,_ad,_ab,_??,_??,_db,_ad,_db
		DB _ad,_db,_da,_ad,_cd,_ad,_dc,_ba
		DB _ad,_ca,_cd,_ab,_ca,_bc,_aa,_dc
		DB _ac,_ad,_cb,_dd,_bb,_cd,_cc,_cd
		DB _bd,_ba,_ad,_aa,_ab,_dc,_aa,_ba
		DB _ad,_ad,_bc,_cb,_da,_cd,_dc,_db
		DB _db,_aa,_dd,_bc,_bd,_bb,_bc,_aa
		DB _dc,_cb,_dc,_ba,_ac,_aa,_ac,_ad
		DB _cb,_da,_cb,_ca,_dc,_bd,_dd,_cc
		DB _db,_aa,_db,_ac,_dc,_aa,_ac,_ab
		DB _db,_cd,_cd,_ba,_db,_bb,_da,_ca
		DB _dc,_dd,_cc,_dc,_cc,_ac,_dc,_db


Grid			DB GRID_SIZE*GRID_SIZE dup(?)

end start