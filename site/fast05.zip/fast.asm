;       Fast compo at LTP4
;       by Valdor / Paradise Studios
;       Searching 4 the hole

                org 100h
                section .text
start:
                mov             si,grid
;                mov             cx,255
mainloop:
                lodsb
                int             29h
                test            cx,15
                jnz             crskip
                mov             al,13
                int             29h
                mov             al,10
                int             29h
crskip:
                dec             cx
                jns              mainloop

                ret


                section .data align=1

grid:           db "adbdcdbdddcbdbab"
                db "bccbddbccaadcdaa"
                db "dabdacdbbdacaccd"
                db "cdababcacbdcadca"
                db "baadababcddbaddb"
                db "addbdaadcdaddcba"
                db "adcacdabcabcaadc"
                db "acadcbddbbcdcccd"
                db "bdbaadaaabdcaaba"
                db "adadbccbdacddcdb"
                db "dbaaddbcbdbbbcaa"
                db "dccbdcbaacaaacad"
                db "cbdacbcadcbdddcc"
                db "dbaadbacdcaaacab"
                db "dbcdcdbadbbbdaca"
                db "dcddccdcccacdcdb"

                section .bss
